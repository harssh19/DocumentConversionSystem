﻿using System;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Net.Http.Handlers;

namespace ConsoleApp2
{
    class Program
    {

        private static void HttpReceiveProgress(object sender, HttpProgressEventArgs e)
        {
            // The sender is the originating HTTP request
            HttpRequestMessage request = sender as HttpRequestMessage;

            // Write different message depending on whether we have a total length or not
            string message;
            if (e.TotalBytes != null)
            {
                message = String.Format("Request {0} downloaded {1} of {2} bytes ({3}%)", request.RequestUri, e.BytesTransferred, e.TotalBytes, e.ProgressPercentage);
            }
            else
            {
                message = String.Format("Request {0} downloaded {1} bytes", request.RequestUri, e.BytesTransferred, e.TotalBytes, e.ProgressPercentage);
            }

            // Write progress message to console
            Console.WriteLine(message);
        }

        private static void HttpSendProgress(object sender, HttpProgressEventArgs e)
        {
            // The sender is the originating HTTP request
            HttpRequestMessage request = sender as HttpRequestMessage;

            // Write different message depending on whether we have a total length or not
            string message;
            if (e.TotalBytes != null)
            {
                message = String.Format("Request {0} downloaded {1} of {2} bytes ({3}%)", request.RequestUri, e.BytesTransferred, e.TotalBytes, e.ProgressPercentage);
            }
            else
            {
                message = String.Format("Request {0} downloaded {1} bytes", request.RequestUri, e.BytesTransferred, e.TotalBytes, e.ProgressPercentage);
            }

            // Write progress message to console
            Console.WriteLine(message);
        }


        static void Main(string[] args)
        {
            // Create a progress notification handler and wire up events for upload and download progress
            ProgressMessageHandler progress = new ProgressMessageHandler();
            progress.HttpReceiveProgress += new EventHandler<HttpProgressEventArgs>(HttpReceiveProgress);
            progress.HttpSendProgress += new EventHandler<HttpProgressEventArgs>(HttpSendProgress);
            
            
            // Create a client and wire up the progress handler
            HttpClient client = HttpClientFactory.Create(progress);

            // We can now submit an HTTP request and see the progress notifications in action
            client.GetAsync("http://msdn.microsoft.com").ContinueWith(
            (requestTask) =>
            {
                if (requestTask.IsCanceled)
                {
                    Console.WriteLine("Request was cancelled");
                }

                if (requestTask.IsFaulted)
                {
                    Console.WriteLine("Request failed with an exception: {0}", requestTask.Exception.GetBaseException());
                }

                HttpResponseMessage response = requestTask.Result;
                {
                    Console.WriteLine("Request succeeded");
                }
            });

            Console.ReadKey();
        }
    }
}
