﻿#region Using
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using Automation.Anywhere.WebAPI.API.Core.Controllers;
using Automation.Anywhere.WebAPI.Domain;
using Automation.Anywhere.WebAPI.Tests.Helpers;
#endregion

namespace Automation.Anywhere.WebAPI.Tests
{
    [TestFixture]
    public class RouteTests
    {
        #region Variables
        HttpConfiguration _config;
        #endregion

        #region Setup
        [SetUp]
        public void Setup()
        {
            _config = new HttpConfiguration();
            _config.Routes.MapHttpRoute(name: "DefaultWebAPI", routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional });
        }
        #endregion

        #region Tests
        [Test]
        public void RouteShouldControllerGetDocumentIsInvoked()
        {
            var request = new HttpRequestMessage(HttpMethod.Get, "http://www.harshal.com/api/documents/5");

            var _actionSelector = new ControllerActionSelector(_config, request);

            Assert.That(typeof(DocumentsController), Is.EqualTo(_actionSelector.GetControllerType()));
            Assert.That(GetMethodName((DocumentsController c) => c.GetDocument(5)),
                Is.EqualTo(_actionSelector.GetActionName()));
        }

        [Test]
        public void RouteShouldPostDocumentActionIsInvoked()
        {
            var request = new HttpRequestMessage(HttpMethod.Post, "http://www.harshal.com/api/documents/");

            var _actionSelector = new ControllerActionSelector(_config, request);

            Assert.That(GetMethodName((DocumentsController c) =>
                c.PostDocument(new Document())), Is.EqualTo(_actionSelector.GetActionName()));
        }

        [Test]
        public void RouteShouldInvalidRouteThrowException()
        {
            var request = new HttpRequestMessage(HttpMethod.Post, "http://www.harshal.com/api/InvalidController/");

            var _actionSelector = new ControllerActionSelector(_config, request);

            Assert.Throws<HttpResponseException>(() => _actionSelector.GetActionName());
        }

        #endregion

        #region Helper methods
        public static string GetMethodName<T, U>(Expression<Func<T, U>> expression)
        {
            var method = expression.Body as MethodCallExpression;
            if (method != null)
                return method.Method.Name;

            throw new ArgumentException("Expression is wrong");
        }
        #endregion
    }
}
